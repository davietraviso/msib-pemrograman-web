export const navLinks = [
  {
    id: 1,
    path: "",
    text: "Beranda",
  },
  {
    id: 2,
    path: "produk",
    text: "Produk",
  },
  {
    id: 3,
    path: "jasa",
    text: "Jasa",
  },
  {
    id: 4,
    path: "blog",
    text: "Blog",
  },
  {
    id: 5,
    path: "tentang-kami",
    text: "Tentang Kami",
  },
];

