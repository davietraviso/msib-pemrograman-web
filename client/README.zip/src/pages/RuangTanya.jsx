 
 
const RuangTanya = () => {
  return (
    <div>RuangTanya</div>
  )
}

export default RuangTanya